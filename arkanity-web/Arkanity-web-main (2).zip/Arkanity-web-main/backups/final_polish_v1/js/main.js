/**
 * ARKANITY - Main JavaScript
 * Bulgarian Google Reviews Management Platform
 * Production-ready code with all features
 */

'use strict';

// ========================================
// NAVBAR SCROLL EFFECT
// ========================================
const navbar = document.getElementById('navbar');
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;

    if (currentScroll > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }

    lastScroll = currentScroll;
});

// ========================================
// MOBILE MENU
// ========================================
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const mobileMenuClose = document.getElementById('mobile-menu-close');
const mobileMenu = document.getElementById('mobile-menu');
const mobileMenuLinks = mobileMenu ? mobileMenu.querySelectorAll('a') : [];

function openMobileMenu() {
    if (mobileMenu) {
        mobileMenu.classList.remove('translate-x-full');
        document.body.style.overflow = 'hidden';
    }
}

function closeMobileMenu() {
    if (mobileMenu) {
        mobileMenu.classList.add('translate-x-full');
        document.body.style.overflow = '';
    }
}

if (mobileMenuBtn) mobileMenuBtn.addEventListener('click', openMobileMenu);
if (mobileMenuClose) mobileMenuClose.addEventListener('click', closeMobileMenu);

mobileMenuLinks.forEach(link => {
    link.addEventListener('click', closeMobileMenu);
});

// ========================================
// BACK TO TOP BUTTON
// ========================================
const backToTop = document.getElementById('back-to-top');

if (backToTop) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 500) {
            backToTop.style.opacity = '1';
            backToTop.style.transform = 'translateY(0)';
            backToTop.style.pointerEvents = 'auto';
        } else {
            backToTop.style.opacity = '0';
            backToTop.style.transform = 'translateY(10px)';
            backToTop.style.pointerEvents = 'none';
        }
    });

    backToTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// ========================================
// MOBILE STICKY CTA
// ========================================
const mobileStickyCta = document.getElementById('mobile-sticky-cta');

if (mobileStickyCta) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 800) {
            mobileStickyCta.classList.remove('translate-y-full');
        } else {
            mobileStickyCta.classList.add('translate-y-full');
        }
    });
}

// ========================================
// TRANSLATION HELPER
// ========================================
function t(key) {
    const lang = document.documentElement.lang || 'bg';
    if (window.translations && window.translations[lang] && window.translations[lang][key]) {
        return window.translations[lang][key];
    }
    return key;
}

// ========================================
// MODAL SYSTEM
// ========================================
const customModal = document.getElementById('custom-modal');
const modalContent = document.getElementById('modal-content');
const modalTitle = document.getElementById('modal-title');
const modalMessage = document.getElementById('modal-message');
const modalIcon = document.getElementById('modal-icon');
const modalClose = document.getElementById('modal-close');
const modalBackdrop = document.getElementById('modal-backdrop');

function showModal(title, message, isSuccess = true) {
    if (!customModal) return;

    modalTitle.textContent = title;
    modalMessage.textContent = message;

    if (isSuccess) {
        modalIcon.innerHTML = '<i class="fa-solid fa-check"></i>';
        modalIcon.className = 'w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary text-3xl mx-auto mb-4';
    } else {
        modalIcon.innerHTML = '<i class="fa-solid fa-xmark"></i>';
        modalIcon.className = 'w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center text-red-500 text-3xl mx-auto mb-4';
    }

    customModal.style.opacity = '1';
    customModal.style.pointerEvents = 'auto';
    modalContent.style.transform = 'scale(1)';
}

function hideModal() {
    if (!customModal) return;

    customModal.style.opacity = '0';
    customModal.style.pointerEvents = 'none';
    modalContent.style.transform = 'scale(0.95)';
}

if (modalClose) modalClose.addEventListener('click', hideModal);
if (modalBackdrop) modalBackdrop.addEventListener('click', hideModal);

// ========================================
// FORM SUBMISSION
// ========================================
const forms = document.querySelectorAll('form');

forms.forEach(form => {
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;

        // Show loading
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-2"></i>${t('form.sending')}`;

        const formData = new FormData(form);
        const data = Object.fromEntries(formData);

        try {
            // Netlify AJAX submission
            const response = await fetch("/", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams(formData).toString(),
            });

            if (response.ok) {
                showModal(
                    t('form.success.title'),
                    t('form.success.message'),
                    true
                );
                form.reset();

                // Track conversion
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'generate_lead', {
                        'event_category': 'engagement',
                        'event_label': form.getAttribute('name') || 'unknown_form'
                    });
                }
            } else {
                throw new Error('Form submission failed');
            }
        } catch (error) {
            console.error('Form error:', error);
            showModal(
                t('form.error.title'),
                t('form.error.message'),
                false
            );
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    });
});

// ========================================
// COOKIE CONSENT
// ========================================
const cookieBanner = document.getElementById('cookie-banner');

function checkCookieConsent() {
    const consent = localStorage.getItem('arkanity-cookie-consent');
    if (!consent && cookieBanner) {
        setTimeout(() => {
            cookieBanner.style.display = 'block';
            setTimeout(() => {
                cookieBanner.classList.add('show');
            }, 100);
        }, 2000);
    }
}

function acceptCookies() {
    localStorage.setItem('arkanity-cookie-consent', 'accepted');
    if (cookieBanner) {
        cookieBanner.classList.remove('show');
        setTimeout(() => {
            cookieBanner.style.display = 'none';
        }, 400);
    }

    // Initialize analytics
    if (typeof gtag !== 'undefined') {
        gtag('consent', 'update', {
            'analytics_storage': 'granted'
        });
    }
}

function rejectCookies() {
    localStorage.setItem('arkanity-cookie-consent', 'rejected');
    if (cookieBanner) {
        cookieBanner.classList.remove('show');
        setTimeout(() => {
            cookieBanner.style.display = 'none';
        }, 400);
    }
}

// Make functions global
window.acceptCookies = acceptCookies;
window.rejectCookies = rejectCookies;

// ========================================
// TIMED SPECIAL OFFER POPUP
// ========================================
let popupShown = false;

// Show popup after 30 seconds of browsing
setTimeout(() => {
    if (!popupShown && !localStorage.getItem('arkanity-popup-closed')) {
        popupShown = true;

        showModal(
            t('popup.title'),
            t('popup.message'),
            true
        );

        // Modify button for download
        if (modalClose) {
            modalClose.textContent = t('popup.btn');
            modalClose.onclick = () => {
                window.open('arkanity_besplaten_audit_reputatsiya.pdf', '_blank');

                // Track download
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'file_download', {
                        'file_name': 'arkanity_besplaten_audit_reputatsiya.pdf'
                    });
                }

                localStorage.setItem('arkanity-popup-closed', 'true');
                hideModal();
            };
        }
    }
}, 20000); // 20 seconds delay

// ========================================
// DEMO INTERACTIVE WIDGET
// ========================================
const demoStars = document.getElementById('demo-stars');
const phoneScreen1 = document.getElementById('phone-screen-1');
const phoneScreenFeedback = document.getElementById('phone-screen-feedback');
const demoResultPanel = document.getElementById('demo-result-panel');
const resultIcon = document.getElementById('result-icon');
const resultTitle = document.getElementById('result-title');
const resultDesc = document.getElementById('result-desc');

if (demoStars) {
    const stars = demoStars.querySelectorAll('i');
    let selectedRating = -1;

    function fillStars(maxIndex) {
        stars.forEach((s, i) => {
            if (i <= maxIndex) {
                s.classList.add('text-yellow-400');
                s.classList.remove('text-gray-300');
            } else {
                s.classList.remove('text-yellow-400');
                s.classList.add('text-gray-300');
            }
        });
    }

    stars.forEach((star, index) => {
        // Hover effect
        star.addEventListener('mouseenter', () => fillStars(index));

        // Reset stars on mouse leave to the selected rating
        star.addEventListener('mouseleave', () => fillStars(selectedRating));

        star.addEventListener('click', () => {
            selectedRating = index;
            const rating = index + 1;

            // Keep stars filled after click
            fillStars(index);

            // Remove listeners to "lock" the demo or prevent multiple flashes
            // (Optional: let them click again)

            // Slide to feedback screen
            setTimeout(() => {
                if (phoneScreen1) phoneScreen1.classList.add('translate-x-[-100%]');
                if (phoneScreenFeedback) phoneScreenFeedback.classList.remove('translate-x-full');

                // Show result based on rating
                if (rating >= 4) {
                    // Good rating - redirect to Google
                    phoneScreenFeedback.innerHTML = `
                        <div class="w-16 h-16 bg-green-500/20 rounded-full mb-6 flex items-center justify-center text-4xl">✅</div>
                        <h3 class="text-dark font-bold text-xl mb-2">${t('demo.good.title')}</h3>
                        <p class="text-gray-500 text-sm mb-6">${t('demo.good.desc')}</p>
                        <div class="w-full h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold">
                            <i class="fa-brands fa-google mr-2"></i> ${t('demo.good.btn')}
                        </div>
                    `;

                    if (demoResultPanel) {
                        demoResultPanel.style.opacity = '1';
                        demoResultPanel.style.transform = 'translateY(0)';
                    }
                    if (resultIcon) resultIcon.textContent = '🎯';
                    if (resultTitle) resultTitle.textContent = t('demo.result.good.title');
                    if (resultDesc) resultDesc.textContent = t('demo.result.good.desc');
                } else {
                    // Bad rating - private feedback
                    phoneScreenFeedback.innerHTML = `
                        <div class="w-16 h-16 bg-orange-500/20 rounded-full mb-6 flex items-center justify-center text-4xl">📝</div>
                        <h3 class="text-dark font-bold text-xl mb-2">${t('demo.bad.title')}</h3>
                        <p class="text-gray-500 text-sm mb-6">${t('demo.bad.desc')}</p>
                        <textarea class="w-full h-24 p-3 border rounded-lg text-sm" placeholder="${t('demo.bad.placeholder')}"></textarea>
                        <button class="mt-4 w-full bg-gray-800 text-white py-3 rounded-lg font-bold">${t('demo.bad.btn')}</button>
                    `;

                    if (demoResultPanel) {
                        demoResultPanel.style.opacity = '1';
                        demoResultPanel.style.transform = 'translateY(0)';
                    }
                    if (resultIcon) resultIcon.textContent = '🛡️';
                    if (resultTitle) resultTitle.textContent = t('demo.result.bad.title');
                    if (resultDesc) resultDesc.textContent = t('demo.result.bad.desc');
                }

                // Auto-reset demo after 5 seconds
                setTimeout(() => {
                    selectedRating = -1;
                    fillStars(-1);
                    if (phoneScreen1) phoneScreen1.classList.remove('translate-x-[-100%]');
                    if (phoneScreenFeedback) phoneScreenFeedback.classList.add('translate-x-full');
                    if (demoResultPanel) {
                        demoResultPanel.style.opacity = '0';
                        demoResultPanel.style.transform = 'translateY(10px)';
                    }
                }, 5000);
            }, 300);
        });
    });
}

// ========================================
// HERO IMAGE ROTATION
// ========================================
const heroSlides = document.querySelectorAll('.hero-slide');
let currentSlide = 0;

if (heroSlides.length > 0) {
    setInterval(() => {
        heroSlides[currentSlide].style.opacity = '0';
        currentSlide = (currentSlide + 1) % heroSlides.length;
        heroSlides[currentSlide].style.opacity = '1';
    }, 5000);
}

// ========================================
// SCROLL REVEAL
// ========================================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in-up');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('section').forEach(section => {
    observer.observe(section);
});

// ========================================
// INITIALIZE ON LOAD
// ========================================
document.addEventListener('DOMContentLoaded', () => {
    checkCookieConsent();
    console.log('🚀 Arkanity loaded successfully');
});
